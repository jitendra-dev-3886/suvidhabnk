<?php
session_start();
include_once("../../../../Db/config.php");

// $usid = $_SESSION['UsId'];
// $usid = 123;
// echo '<script type ="text/JavaScript">';  
// echo 'alert("'.$usid.'")';  
// echo '</script>'; 

// exit;
?>



<!DOCTYPE html>
<html>
<head>
	<title>Cashfree - PG Response Details</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	<h1 align="center">Response</h1>
	<!--<h1 align="center">PG Response</h1>-->

	<?php  
		 $secretkey = "ce6d2be6d1c250f8c77b727abcc1839e3696b98c";
// 		 $secretkey = "03aad79a42df46d8e0145c5b1ff76512ec3440ec";
		 $orderId = $_POST["orderId"];
		 $orderAmount = $_POST["orderAmount"];
		 $referenceId = $_POST["referenceId"];
		 $txStatus = $_POST["txStatus"];
		 $paymentMode = $_POST["paymentMode"];
		 $txMsg = $_POST["txMsg"];
		 $txTime = $_POST["txTime"];
		 $signature = $_POST["signature"];
		 $data = $orderId.$orderAmount.$referenceId.$txStatus.$paymentMode.$txMsg.$txTime;
		 $hash_hmac = hash_hmac('sha256', $data, $secretkey, true) ;
		 $computedSignature = base64_encode($hash_hmac);
		 if ($signature == $computedSignature) {
	 ?>
	<div class="container"> 
	<div class="panel panel-success">
	  <div class="panel-heading">Signature Verification Successful</div>
	  <div class="panel-body">
	  	<!-- <div class="container"> -->
	 		<table class="table table-hover">
			    <tbody>
			      <tr>
			        <td>Order ID</td>
			        <td><?php echo $orderId; ?></td>
			      </tr>
			      <tr>
			        <td>Order Amount</td>
			        <td><?php echo $orderAmount; ?></td>
			      </tr>
			      <tr>
			        <td>Reference ID</td>
			        <td><?php echo $referenceId; ?></td>
			      </tr>
			      <tr>
			        <td>Transaction Status</td>
			        <td><?php echo $txStatus; ?></td>
			      </tr>
			      <tr>
			        <td>Payment Mode </td>
			        <td><?php echo $paymentMode; ?></td>
			      </tr>
			      <tr>
			        <td>Message</td>
			        <td><?php echo $txMsg; ?></td>
			      </tr>
			      <tr>
			        <td>Transaction Time</td>
			        <td><?php echo $txTime; ?></td>
			      </tr>
			    </tbody>
			</table>
		<!-- </div> -->

	   </div>
	</div>
	 Go to Dashboard <a href="https://suvidhabnk.com/Agent/">Click Here</a>
	</div>
	 <?php   
	  	} else {
	 
	 ?>
	<div class="container"> 
	<div class="panel panel-danger">
	  <div class="panel-heading">Signature Verification failed</div>
	  <div class="panel-body">
	  	<!-- <div class="container"> -->
	 		<table class="table table-hover">
			    <tbody>
			      <tr>
			        <td>Order ID</td>
			        <td><?php echo $orderId; ?></td>
			      </tr>
			      <tr>
			        <td>Order Amount</td>
			        <td><?php echo $orderAmount; ?></td>
			      </tr>
			      <tr>
			        <td>Reference ID</td>
			        <td><?php echo $referenceId; ?></td>
			      </tr>
			      <tr>
			        <td>Transaction Status</td>
			        <td><?php echo $txStatus; ?></td>
			      </tr>
			      <tr>
			        <td>Payment Mode </td>
			        <td><?php echo $paymentMode; ?></td>
			      </tr>
			      <tr>
			        <td>Message</td>
			        <td><?php echo $txMsg; ?></td>
			      </tr>
			      <tr>
			        <td>Transaction Time</td>
			        <td><?php echo $txTime; ?></td>
			      </tr>
			    </tbody>
			</table>
		<!-- </div> -->
	  </div>	
	</div>	
	Go to Dashboard <a href="https://suvidhabnk.com/Agent/">Click Here</a>
	</div>
	
	<?php	
	 	}
	 ?>



<?php

$data_wallet_cashfree=$con->query("select * from wallet_cashfree where ORDER_ID='$orderId'")->fetch_assoc();
$user_id=$data_wallet_cashfree['USER_ID'];


$user_detai=$con->query("select * from user where ID='$user_id'")->fetch_assoc();
$user_token=$user_detai['TOKEN_ID'];




if($txStatus =='SUCCESS'){
    $userdet=$con->query("select * from user where ID='$user_id'")->fetch_assoc();
    $user_main=$userdet['MAIN_BAL'];
    $user_token=$userdet['TOKEN_ID'];
    $new_bal=$user_main+$orderAmount;
    $userlogin=$con->query("select * from `login_history` where `USER_ID`='$user_id'")->fetch_assoc();
    $user_IP=$userlogin['IP_ADDRESS'];
    $user_browser=$userlogin['BROWSER'];
    $user_os=$userlogin['OPERATING_SYSTEM'];
    $user_device=$userlogin['DEVICE'];
    $user_country=$userlogin['COUNTRY'];
    $user_city=$userlogin['CITY'];
    $user_zip=$userlogin['ZIP'];
    $date=date('Y-m-d');
    $datetime=date('Y-m-d H:i:s');
    
    // echo $user_main; 
    // echo $new_bal;
    
    $up_us_main=$con->query("update user set `MAIN_BAL`='$new_bal' where `ID`='$user_id'");
    
    
    $insert_report=$con->query("INSERT INTO `report`(`OWNER`, `OWNER_ID`, `TRANS_TYPE`, `REFERENCE_ID`, `TOKEN_ID`, `USER_ID`, `TRANSFER_USER_ID`, `PREVIOUS_AMOUNT`, `AMOUNT`, `AFTER_AMOUNT`, `FUND_TYPE`, `WALLET`, `REMARK`, `STATUS`, `IP_ADDRESS`, `BROWSER`, `OS`, `DEVICE`, `LOCATION`, `TRANS_DATE`, `TRANS_TIME`, `COUNTRY`, `STATE`, `CITY`, `ZIP`, `LATTITUDE`, `LONGITUDE`, `API_IP`, `INTERNET_ISP`, `INTERNET_ORG`, `MESSAGE`, `DATE`, `ALL_MAIN`, `ALL_AEPS`, `APITYPE`) VALUES ('Admin', '1', 'Recharge Main Wallet', '$orderId', '$user_token', '$user_id', '', '$user_main', '$orderAmount', '$new_bal', 'Credit', 'MAIN', 'Main Wallet Money added', '', '$user_IP', '$user_browser', '$user_os', '$user_device', '', '$date', '$txTime', '$user_country', '', '$user_city', '$user_zip', '', '', '', '', '', '', '$datetime', '', '', '')");

    
    
    
}

    $update_wallet_cashfree=$con->query("update `wallet_cashfree` set `REFERENCE_ID`='$referenceId', `TRANSACTION_STATUS`='$txStatus', `PAYMENT_MODE`='$paymentMode' ,`MESSAGE`='$txMsg',`TRANSACTION_TIME`='$txTime' where `ORDER_ID`='$orderId'");
    
    
    
    $_SESSION["UsId"] = $user_id;
    $_SESSION["Token"] = $user_token;

?>




</body>
</html>



