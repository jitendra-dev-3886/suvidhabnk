<?php

    include("../../../Db/config.php");
    include("../Userinfo/getuserinfo.php");
    include("../Functions/all_function.php");
    include("../Auth/userdata.php");
    
    if($_POST['fetch_all']=="fetch_all"){
        
        $userData = [
                "email"=>$user["EMAIL"],
                "mobile"=>$user["MOBILE"],
                "password"=>$user["PASSWORD"],
                "name"=>$user['FIRST_NAME'],
                "lastname"=>$user['LAST_NAME'],
                "ownerid"=>$user['MAIN_OWNER_ID'],
                "ownerstatus"=>$user['MAIN_OWNER'],
                "userstatus"=>$user['USER_TYPE'],
                "token"=>$user['TOKEN_ID'],
                "id"=>$user['ID'],
                "mainbalance"=>number_format($user['MAIN_BAL'], 1, '.', ''),
                "aepsbalance"=>number_format($user['AEPS_BAL'], 1, '.', ''),
                "pin"=>$user['PIN'],
                "address"=>$user['ADDRESS']
        ];
        $recieveable = ["user"=>$userData, "userProfile"=>$profile];
        echo json_encode(["message"=>"Success", "response_code"=>1, "status"=>true, "receivableData"=>$recieveable]);
    }
    
    
    if($_POST['paysprint_cred']=="paysprint_cred"){
        
        $user_mobile = $user['MOBILE'];
    
        $mysql_qry = "select * FROM aeps_merchant WHERE MOBILE ='$user_mobile' and STATUS='1'";
        $result = mysqli_query($con ,$mysql_qry);
        if(mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_array($result);
                
                $myArr = array(
                "result" =>true,
                "message" =>"Access Granted",
                "ref_no" =>$row['REF_NO'],
                "txn_id" =>$row['TXN_ID'],
                "status" =>$row['STATUS'],
                "partnerid" =>$row['PARTNERID'],
                "merchantcode" =>$row['MERCHANTCODE'],
                "isicicikyc" =>$row['IS_ICICI_KYC'],
                "timestamp" =>$row['TIMESTAMP'],
                "owner" =>$row['OWNER'],
                "ownerid"=>$row['OWNER_ID'],
                "api_firm"=>$paysprint['FIRM'],
                "api_jwt"=>$paysprint['JWT_KEY'],
                "api_mechant_code"=>$paysprint['MERCHANT_CODE'],
                "api_partner_id"=>$paysprint['PARTNER_ID']
                );
        

            echo json_encode(["message"=>"Success", "response_code"=>1, "status"=>true, "receivableData"=>$myArr]);
            exit;
        }
        else{
            
            $myArr = array(
                "result" =>false,
                "message" =>"Not Granted",
                "ref_no" =>"",
                "txn_id" =>"",
                "status" =>"",
                "partnerid" =>"",
                "merchantcode" =>"",
                "isicicikyc" =>"",
                "timestamp" =>"",
                "owner" =>"",
                "ownerid"=>"",
                "api_firm"=>$paysprint['FIRM'],
                "api_jwt"=>$paysprint['JWT_KEY'],
                "api_mechant_code"=>$paysprint['MERCHANT_CODE'],
                "api_partner_id"=>$paysprint['PARTNER_ID']
                );
        
             $recieveable = ["user"=>$userData, "userProfile"=>$profile];
            echo json_encode(["message"=>"Success", "response_code"=>1, "status"=>true, "receivableData"=>$myArr]);
            exit;
            
        }
        
    }
    
    
    if($_POST['fetchBeneficiary']=="fetchBeneficiary"){
        
        extract($_POST);
        
        $response = array();
        
        $op = $con->query("select * FROM cashfree_beneficiary WHERE REMIT_MOBILE='$remitMobile' ORDER BY ID DESC");
        // $op = $con->query("select * FROM cashfree_beneficiary WHERE US_ID='$usid' and REMIT_MOBILE='$remitMobile' ORDER BY ID DESC");
        if($op->num_rows > 0)
        {
         while($row = $op->fetch_assoc()){

            $res = $row['VERIFY_RESPONSE'];
            $rspns = json_decode($res , true);
            $benename = $rspns['result']['bankTransfer']['beneName'];
            $bankrrn = $rspns['result']['bankTransfer']['bankRRN'];
            $active = $rspns['result']['active'];
            $mobileMatch = $rspns['result']['mobileMatch'];
            $nameMatch = $rspns['result']['nameMatch'];
            
            if($bankrrn!="" && $active!=""){
                $isVerified = true;
            }
            else{
                $isVerified = false;
            }
            array_push($response,array("ID"=>$row["ID"],"NAME"=>$row['NAME'],"EMAIL"=>$row['EMAIL'],"MOBILE"=>$row['MOBILE'],"ACCOUNT"=>$row['ACCOUNT'],"IFSC"=>$row['IFSC'],"ADDRESS"=>$row['ADDRESS'],"BENEID"=>$row['BENEID'],"DATE"=>$row['DATE'],"isVerified"=>$isVerified));

         }
             echo json_encode(["message"=>"Success", "response_code"=>1, "status"=>true, "receivableData"=>$response]);
        }
        else{
            
            echo json_encode(["message"=>"No Records", "response_code"=>2, "status"=>false]);
        }    
        
    }
    
    
    if($_POST['payout_account_disp']=="payout_account_disp"){
        
        $mysql_qry = "SELECT * FROM payout_users WHERE US_ID ='$usid' AND STATUS ='Success' ORDER BY ID DESC LIMIT 1";
        $result = mysqli_query($con ,$mysql_qry);
        if(mysqli_num_rows($result) > 0) {
            
            $row = mysqli_fetch_array($result);
            echo json_encode(["message"=>"Success", "response_code"=>1, "status"=>true, "receivableData"=>$row]);
        }
        else{
            
            echo json_encode(["message"=>"Payout Account Doesn't Exist, Contact Admin", "response_code"=>2, "status"=>false]);
        } 
      
    }
    
    
    if($_POST['virtual_account_disp']=="virtual_account_disp"){
        
        $mysql_qry = "SELECT * FROM virtual_account WHERE USER_ID ='$usid' ORDER BY ID DESC LIMIT 1";
        $result = mysqli_query($con ,$mysql_qry);
        if(mysqli_num_rows($result) > 0) {
            
            $row = mysqli_fetch_array($result);
            echo json_encode(["message"=>"Success", "response_code"=>1, "status"=>true, "receivableData"=>$row]);
        }
        else{
            echo json_encode(["message"=>"Virtual Account Doesn't Exist, Contact Admin", "response_code"=>2, "status"=>false]);
        } 
      
    }
    
    
    if($_POST['pdmt_history']=="pdmt_history"){
        
        $mb = $_POST['remitter_mobile'];
        
        $mysql_qry = "SELECT * FROM dmt_transactions WHERE USER_ID ='$usid' AND MOBILE ='$mb' ORDER BY ID DESC";
        $result = mysqli_query($con ,$mysql_qry);
        if(mysqli_num_rows($result) > 0) {
            
            $row = mysqli_fetch_all($result, MYSQLI_ASSOC);
            echo json_encode(["message"=>"Success", "response_code"=>1, "status"=>true, "receivableData"=>$row]);
        }
        else{
            echo json_encode(["message"=>"No Records", "response_code"=>2, "status"=>false]);
        } 
      
    }
    
    if($_POST['pxdmt_history']=="pxdmt_history"){
        
        $mb = $_POST['remitter_mobile'];
        
        $mysql_qry = "SELECT * FROM xdmt_transactions WHERE USER_ID ='$usid' AND MOBILE ='$mb' ORDER BY ID DESC";
        $result = mysqli_query($con ,$mysql_qry);
        if(mysqli_num_rows($result) > 0) {
            
            $row = mysqli_fetch_all($result, MYSQLI_ASSOC);
            echo json_encode(["message"=>"Success", "response_code"=>1, "status"=>true, "receivableData"=>$row]);
        }
        else{
            echo json_encode(["message"=>"No Transaction Found", "response_code"=>2, "status"=>false]);
        } 
      
    }

?>