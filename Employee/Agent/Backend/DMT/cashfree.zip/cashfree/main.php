<?php
session_start();
include("../../../../Db/config.php");
include("../../Userinfo/getuserinfo.php");
include("../../Functions/all_function.php");
include("../../Auth/userdata.php");
include('dmt_function.php');
$time = date("Y-m-d g:i:s A");

// Send otp for registeration
if(isset($_POST['send_otp'])){
    $mb = $_POST['mobile'];
    if($_POST['otpSendTime'] > 3){
        
        $receivableData = ["rs_code"=>500 , "smsotpst" => "OTP Send Limit exceeds. Please try again after some time."];
        
        
        
        $err = ["response_code"=>500, "message"=>"OTP Send Limit exceeds. Please try again after some time.", "status"=>false, "receivableData"=>$receivableData];
        echo json_encode($err);
        exit;
        
    }
    
    $olduser = $con->query("select * from cf_dmt_user where MOBILE='$mb' ")->num_rows;
    if($olduser >= 1){
        $rscode = 111;
        echo json_encode(["rs_code"=>$rscode]);
        exit;
    }
    else{
      $otp = mt_rand(99999 , 999999);
      $mbmsg = urlencode("Your OTP verification code is $otp. Do not share it with anyone. TEAM CYBDEER");
      $smsrs = json_decode(sendSMS($mb, $mbmsg , 1307162488475711397) , true);
      echo json_encode(["rs_code"=>112 ,  "smsotpst"=> $smsrs['ErrorMessage'] , "OTPHASH"=>encrypt_token($otp) ]);
      exit;
    }
  
}

// Send otp for send amount
if(isset($_POST['sendamountotp'])){
    $amount = $_POST['send_amount'];
    if($amount == ""){
      echo json_encode(["rs_code"=>112 ,  "message"=>"Amount cannot be empty." ]);
      exit;
    }
    
    // send OTP on agent mobile
    
      $otp2 = mt_rand(99999 , 999999);
      $mbmsg2 = urlencode("Your OTP verification code is $otp2. Do not share it with anyone. TEAM CYBDEER");
      $smsrs2 = json_decode(sendSMS($user['MOBILE'] , $mbmsg2 , 1307162488475711397) , true);
      echo json_encode(["rs_code"=>111 , "smsotpst2"=> $smsrs2['ErrorMessage'] , "OTPHASH2"=>encrypt_token($otp2) ]);
      exit;
}


if(isset($_POST['hash_code'])){
    extract($_POST);
    
if($otp == ""){
    echo json_encode(["rscode"=> 403 , "message"=> "OTP Not matched" ]);
     exit;
}

if($hash_code == ""){
    echo json_encode(["rscode"=> 403 , "message"=> "Verification failed" ]);
     exit;
}

if($otp != decrypt_token($hash_code)){
     echo json_encode(["rscode"=> 403 , "message"=> "OTP Not matched " ]);
     exit;
}

    $con->query("INSERT INTO `cf_dmt_user`(`USER_ID`, `ADDRESS`, `PINCODE`, `MOBILE`,`TIMESTAMP`) VALUES ('$usid','$address','$pincode','$mobile','".date("Y-m-d g:i:s")."')");
    echo json_encode(["rs_code"=>111 , "message"=> "Success"]);
}

// Add beneficiary 
if (isset($_POST['beneName'])) {
    extract($_POST);
    $beneList = $con->query("select * from cashfree_beneficiary where ACCOUNT='$beneAcc' and IFSC='$beneIFSC' and US_ID='$usid' and REMIT_MOBILE='$remitMobile' ")->num_rows;
    if($beneList >= 1){
        echo json_encode(["subCode" => "301" , "message" => "Bene Already Added in this account "]);
        exit;
    }
    
    $url = "https://payout-api.cashfree.com/payout/v1/addBeneficiary";
    $beneID = "PDR".$usid.date("Ymd").mt_rand(999, 9999);
    $data = json_encode([
        "beneId" => $beneID,
        "name" => $beneName,
        "email" => $beneEmail,
        "phone" => $beneMobile,
        "bankAccount" => $beneAcc,
        "ifsc" => $beneIFSC,
        "address1" => $beneAdd,
    ]);
    $token = create_cashfree_token();
    $headers = array(
        'Content-Type:application/json',
        'Authorization: Bearer ' . $token
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $result = curl_exec($ch);
    echo $result;
    $response = json_decode($result, true);
    $subCode = $response['subCode'];

    if ($subCode == "200") {
        $con->query("INSERT INTO `cashfree_beneficiary`(`NAME`, `EMAIL`, `MOBILE`, `ACCOUNT`, `IFSC`, `ADDRESS`, `BENEID`, `DATE`,`US_ID` , `REMIT_MOBILE`)
        VALUES ('$beneName','$beneEmail','$beneMobile','$beneAcc','$beneIFSC','$beneAdd','$beneID','" . date("Y-m-d") . "','$usid' , '$remitMobile')");
    }
    else if ($subCode == "409") {
        $bene = $con->query("select * from cashfree_beneficiary where MOBILE='$beneMobile' and ACCOUNT='$beneAcc' and IFSC='$beneIFSC' order by ID DESC LIMIT 1")->fetch_assoc();
        $beneId = $bene['BENEID'];
        $con->query("INSERT INTO `cashfree_beneficiary`(`NAME`, `EMAIL`, `MOBILE`, `ACCOUNT`, `IFSC`, `ADDRESS`, `BENEID`, `DATE`,`US_ID`, `REMIT_MOBILE`)
        VALUES ('$beneName','$beneEmail','$beneMobile','$beneAcc','$beneIFSC','$beneAdd','$beneId','" . date("Y-m-d") . "','$usid', '$remitMobile')");
    }
}


// Delete Beneficiary
if (isset($_POST['bene_delete'])) {
    extract($_POST);
    
     $beneList = $con->query("select * from cashfree_beneficiary where `BENEID`='$beneID'")->num_rows;
    if($beneList > 1){
         $con->query("DELETE FROM `cashfree_beneficiary` WHERE `BENEID`='$beneID' and US_ID='$usid' and REMIT_MOBILE='$remitMobile'");
        echo json_encode(["subCode" => "200" , "message" => "Bene Deleted from this account. "]);
        exit;
    }
    
    
    $url = "https://payout-api.cashfree.com/payout/v1/removeBeneficiary";
    $data = json_encode([
        "beneId" => $beneID
    ]);
    $token = create_cashfree_token();
    $headers = array(
        'Content-Type:application/json',
        'Authorization: Bearer ' . $token
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $result = curl_exec($ch);
    echo $result;
    $response = json_decode($result, true);
    $subCode = $response['subCode'];

    if ($subCode == 200) {
        $con->query("DELETE FROM `cashfree_beneficiary` WHERE `BENEID`='$beneID' ");
    }
}


// Send Amount 
if(isset($_POST['send_amount'])){
$bene_id = strip_tags($_POST['bene_id']);
$acc = strip_tags($_POST['send_am_acc']);
$send_amount = strip_tags($_POST['send_amount']);
$hash_code = strip_tags($_POST['smhash_code']);
$hash_code2 = strip_tags($_POST['smhash_code2']);

$otp = strip_tags($_POST['beneOTP']);
$otp2 = strip_tags($_POST['agentOTP']);

// validation of bene otp

if($otp2 == ""){
    echo json_encode(["rscode"=> 403 , "message"=> "Enter Agent  OTP" ]);
     exit;
}

if($hash_code2 == ""){
    echo json_encode(["rscode"=> 403 , "message"=> "Agent Verification failed" ]);
     exit;
}

if($otp2 != decrypt_token($hash_code2)){
     echo json_encode(["rscode"=> 403 , "message"=> "Agent OTP Not matched ".decrypt_token($hash_code2) ]);
     exit;
}

    
 $refrence = "PDR".$usid.date("Ymd").mt_rand(999, 9999);
 $comonRefID =   "PDR".$usid.$bene_id.date("Ymd").mt_rand(999, 9999);


if($send_amount > 25000){
      echo json_encode(array("response_code"=>  400 , "responseReason" => "Error", "message" => "Amount should be less than 25001"));
      exit;
}

$usBal = $user['MAIN_BAL'];
if($usBal > $send_amount){
      
        //spillt the transaction is amount is greater than 5000
        if($send_amount > 5000){
            $sm = ceil($send_amount/5000);
            for($i=0; $i<$sm; $i++)
            {   
                 $refrence =   "PDR".$usid.date("Ymd").mt_rand(999, 9999);
                $snd = 5000;
                if($send_amount > 5000){
                    $am = $send_amount-$snd;
                }
                else{
                    $snd = $send_amount;
                }
                $insert_report = "INSERT INTO `dmt_transactions`(`USER_ID`, `USER_TYPE`, `MOBILE`, `BENE_ID`, `ACCOUNT`, `TIMESTAMP`, `AMOUNT`, `TRANS_TYPE`, `REFFRENCE_ID`, `COMM_REFID`)
                VALUES ('$usid','$ustypeid','$mb','$bene_id','$acc','$time','$snd','$txn_type','$refrence' , '$comonRefID')";
                $user_bal = $usBal-$snd;
                $deduct_bal = "update user set MAIN_BAL='$user_bal' where ID='$usid' and USER_TYPE='$ustypeid'";
                if($con->query($insert_report) && $con->query($deduct_bal) ){
                    $url = "https://payout-api.cashfree.com/payout/v1/requestAsyncTransfer";
           
                      $data = json_encode([
                        "beneId" => $bene_id,
                        "amount" => $snd,
                        "transferId" => $refrence
                    ]);
                    
                    $token = create_cashfree_token();
                    $headers = array(
                        'Content-Type:application/json',
                        'Authorization: Bearer ' . $token
                    );
                
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                    $result = curl_exec($ch);
                    $response = json_decode($result, true);
                    $subCode = $response['subCode'];
                    $status = $response['status'];
                    $msg = $response['message'];
                    $resRefId = $response['data']['referenceId'];
                    
                          $con->query("update dmt_transactions set RESPONSE='".str_replace("'" , "\'" , $result)."'  , STATUS='$status' , RES_REFID='$resRefId'  where REFFRENCE_ID='$refrence' ");
                          if($rs_code != 1 && $status == 0){
                              $con->query("update user set MAIN_BAL='".$user['MAIN_BAL']."' where ID='$usid' and USER_TYPE='$ustypeid' ");
                          }
                          else if($rs_code == 1){
                              insert_allreport($usid  ,$refrence , "DMT" , $user['MAIN_BAL']  , $user_bal , $snd , "Debit" , "DMT Transaction");
                               // retailer commission
                                  if($ustypeid == 46 && strtolower($status) == "success"){
                                      give_dmt_com($refrence , $usid ,$ustypeid);
                                  }
                          }
                    }
                    else{
                        $gotrsnps = json_encode(array("response_code"=>  500 , "message"=>"Some internel server error. We are fixing it"));
                    }
                
                $send_amount =  $am;
                $usBal = $user_bal;
            }
           echo json_encode(array("response_code"=>  1 , "txncount"=>  $sm , "TxnType"=>"111" , "response" => $gotrsnps));  
        }
        else{
          $insert_report = "INSERT INTO `dmt_transactions`(`USER_ID`, `USER_TYPE`, `MOBILE`, `BENE_ID`, `ACCOUNT`, `TIMESTAMP`, `AMOUNT`, `TRANS_TYPE`, `REFFRENCE_ID` , `COMM_REFID`)
            VALUES ('$usid','$ustypeid','$mb','$bene_id','$acc','$time','$send_amount','$txn_type','$refrence' , '$comonRefID')";
            $user_bal = $user['MAIN_BAL']-$send_amount;
            $deduct_bal = "update user set MAIN_BAL='$user_bal' where ID='$usid' and USER_TYPE='$ustypeid'";
            if($con->query($insert_report) && $con->query($deduct_bal) ){
             $url = "https://payout-api.cashfree.com/payout/v1/requestAsyncTransfer";
           
              $data = json_encode([
                "beneId" => $bene_id,
                "amount" => $send_amount,
                "transferId" => $refrence
            ]);
            
            $token = create_cashfree_token();
            $headers = array(
                'Content-Type:application/json',
                'Authorization: Bearer ' . $token
            );
        
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            $result = curl_exec($ch);
            $response = json_decode($result, true);
            $subCode = $response['subCode'];
            $status = $response['status'];
            $msg = $response['message'];
            $resRefId = $response['data']['referenceId'];
                  $con->query("update dmt_transactions set RESPONSE='".str_replace("'" , "\'" , $result)."'  , STATUS='$status' , RES_REFID='$resRefId'  where REFFRENCE_ID='$refrence' ");
                  if($subCode == "200" || $subCode == "201" || $subCode == "202"){
                      insert_allreport($usid  ,$refrence , "DMT" , $user['MAIN_BAL']  , $user_bal , $send_amount , "Debit" , "DMT Transaction");
                       // retailer commission
                          if($ustypeid == 46 && strtolower($status) == "success"){
                              give_dmt_com($refrence , $usid ,$ustypeid);
                          }
                  }
                  else{
                      $con->query("update user set MAIN_BAL='".$user['MAIN_BAL']."' where ID='$usid' and USER_TYPE='$ustypeid' ");
                  }
                  
               echo json_encode(array("response_code"=>  1 ,"txncount"=>1 , "TxnType"=>"112" , "response" => $response));  
                }
            else{
                    echo json_encode(array("response_code"=>  500 , "message"=>"Some internel server error. We are fixing it"));
                }
        }
    }
    else{
        echo json_encode(array("response_code"=>  400 , "message"=>"You have not sufficient balance.. Please add balance."));
    }
}




//Check Status
if(isset($_POST['check_dmt_status'])){
$refrence = trim($_POST['ref_id']);
$txn = $con->query("select * from dmt_transactions where REFFRENCE_ID='$refrence'")->fetch_assoc();
$rsRefId = $txn['RES_REFID'];
$usID = $txn['USER_ID'];
if($rsRefId == ""){
    echo json_encode(array("response_code"=>  400 , "message"=>"Transaction not found for check status."));
    exit;
}
if(strtolower($txn['STATUS']) == "success" || strtolower($txn['STATUS']) == "rejected"){
    echo json_encode(array("response_code"=>  400 , "message"=>"Transaction status already confirmed. "));
    exit;
}
$curl = curl_init();
    $url = "https://payout-api.cashfree.com/payout/v1.1/getTransferStatus?referenceId=$rsRefId";
    // echo $url;
    // exit;
    $token = create_cashfree_token();
    $headers = array(
        'Content-Type:application/json',
        'Authorization: Bearer ' . $token
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $result = curl_exec($ch);
    echo $result;
    $response = json_decode($result, true);
    $subCode = $response['subCode'];
    $status = $response['data']['transfer']['status'];
    $msg = $response['data']['transfer']['reason'];
    if(strtolower($status) == "success"){
          give_dmt_com($refrence , $usID ,46);
    }
    else if(strtolower($status) == "rejected"){
        $user = $con->query("select * from user where ID='$usID' ")->fetch_assoc();
        $refundBal = $user['MAIN_BAL']+$txn['AMOUNT'];
          $con->query("update user set MAIN_BAL='$refundBal' where ID='$usID'");
          
         insert_allreport($usID  ,$refrence , "DMT Failed" , $user['MAIN_BAL']  , $refundBal , $txn['AMOUNT'] , "Credit" , "DMT Transaction Failed");
    }
   $con->query("update dmt_transactions set CHECK_RESPONSE='".str_replace("'" , "\'" , $result)."'   , STATUS='$status'  where REFFRENCE_ID='$refrence' ");
}

