<?php

    include("../includes/config.php");
    $boolstatus = $_POST['boolstatus'];
    $response = $_POST['response'];
    $transAmount = $_POST['transAmount'];
    $balAmount = $_POST['balAmount'];
    $bankRrn = $_POST['bankRrn'];
    $txnid = $_POST['txnid'];
    $transType = $_POST['transType'];
    $type = $_POST['type'];
    $cardNumber = $_POST['cardNumber'];
    $cardType = $_POST['cardType'];
    $terminalId = $_POST['terminalId'];
    $bankName = $_POST['bankName'];
    $message = $_POST['message'];
    $user_id = $_POST['user_id'];
    $user_status = $_POST['user_status'];
    $reference = $_POST['reference'];
    $date = date("Y-m-d H:i:s");
    
        $rs_code = (int)$response;
        if($rs_code == 1 && $boolstatus=="true"){
            $st  = "success";
        }
        else{
            $st = "failed";
        }
        
    
    function encrypt__adhar($simple_string){
$ciphering = "AES-128-CTR";
$options   = 0;
$encryption_iv = 'ThisIsSecretKeyForEncrytionByJisneYeBnaya!@#$%^&*()';
$encryption_key = "WebSpidy";
$encryption = openssl_encrypt($simple_string, $ciphering, $encryption_key, $options, $encryption_iv);
return base64_encode($encryption);

}
function decrypt__adhar($encryption){
    $ciphering = "AES-128-CTR";
     $decryption_iv = 'ThisIsSecretKeyForEncrytionByJisneYeBnaya!@#$%^&*()';
    $decryption_key = "WebSpidy";
    // Using openssl_decrypt() function to decrypt the data 
    $decryption = openssl_decrypt(base64_decode($encryption), $ciphering, $decryption_key, 0, $decryption_iv);
    return $decryption;
}
    
    
    if(isset($_POST['user_id'])){
        
        $id = $_POST['user_id'];
        
    
      include("../includes/fetch_data.php");
      include("../includes/main_function.php");
      include("../aeps/aeps_function.php");
      
            $query = "INSERT INTO `micro_atm`(`USER_ID`, `USER_STATUS`, `RESPONSE`, `TRANSAMOUNT`, `BALAMOUNT`, `BANKRRN`, `TXNID`, `TRANSTYPE`, `TYPE`, `CARDNUMBER`, `CARDTYPE`, `TERMINALLD`, `BANKNAME`, `DATE`) 
            VALUES ('$user_id','$user_status','$response','$transAmount','$balAmount','$bankRrn','$txnid','$transType','$type','$cardNumber','$cardType','$terminalId','$bankName','$date')";
        
            if($type=="BAL" || $type=="ATMBE"){
                //Balance // 
                insert_allreport($id  ,$reference , "ATM" , $user['MAIN_BAL']  , $user['MAIN_BAL'] , $transAmount , "Enquiry" , "Micro Atm Transaction", $ip, $device);
            }else{
                
                
                
                //$old_bal = $user['MAIN_BAL'];
                //$new_bal = (int)$old_bal;
                if($boolstatus=="true" || $st  == "success"){
                    /*    $old_bal = $user['MAIN_BAL'];
                        $new_bal = $old_bal + (int)$transAmount;
                                    $sql = "UPDATE user SET MAIN_BAL='$new_bal' WHERE ID='$id'";
                                    mysqli_query($con, $sql);
                    // give_micro_atm_com($ref_id , $user_id , $user_status, $ip, $device);
                            */
                                    insert_allreport($id  ,$reference , "ATM" , $old_bal  , $new_bal , $transAmount , "Atm Withdraw" , "Micro Atm Transaction", $ip, $device);
                                    give_micro_com($reference , $user_id , $user_status, $ip, $device);
                    
                    
                }
            
                else{
                    insert_allreport($id  ,$reference , "ATM" , $old_bal  , $user['MAIN_BAL'] , $transAmount , "Atm Withdraw" , "Micro Atm Transaction", $ip, $device);
                }
            }
            $run_query = mysqli_query($con , $query);
            if($run_query){
                callToRecon($reference , $st,"Sucessfully Stored");
            }
            else{
                 callToRecon($reference , $st,"Failed to Store");
            }
        
    }
    
    
    function callToRecon($ref , $status, $msg){
    global $con , $paysprint;
    
        $arr = array(
            "reference"=>"$ref",
            "status"=>"$status",
            );
            
        $data_tkn = encrypt($arr);
        $sendData = array(
            "body"=>$data_tkn,
            );
        $main_body = json_encode($sendData , true);
        $token = create_token();
        
        $curl = curl_init();
        curl_setopt_array($curl, [
          CURLOPT_URL => $paysprint['URL']."/api/v1/service/aeps/threeway/threeway",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $main_body,
          CURLOPT_HTTPHEADER => [
             "Content-Type: application/json",
            "Authorisedkey:".$paysprint['AUTHORISED_KEY'],
            "Token:".$token
            ],
        ]);
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        
      echo $msg.'    '.$response;
      $con->query("INSERT INTO `aeps_recon_response`(`DATA`, `RESPONSE`) VALUES ('".json_encode($arr)."','$response')");
}

// Start Micro comission Start
function give_micro_com($ref_id , $user_id , $usertype, $ip_address, $device){
    global $con;
    // echo "dmt com working \n";
$time = date("Y-m-d g:i:s A");
        $user_type_rows = $con->query("select * from user_type ")->num_rows;
        $trans = $con->query("select * from aeps_transactions where REFFRENCE_ID='$ref_id' AND USER_ID='$user_id'")->fetch_assoc();
        $user = $con->query("select * from user  where ID='$user_id' and USER_TYPE='$usertype'")->fetch_assoc();
        $owner = $user['OWNER_ID'];
        $crnt_bal = $user['MAIN_BAL'];
        
        $crnt_aeps_bal = $user['AEPS_BAL'];
        $trans_aeps_bal = $trans['AMOUNT'];
        
        $update_aeps_bal = $crnt_aeps_bal+$trans_aeps_bal;
        
        $com_id = $user['AEPS_COMM'];
        
        //check slab commission package
          $cm_pk_rw = $con->query("select * from slab_commission where COMM_PACK_ID='$com_id' order by ID asc");
        //   code for fetch perticuler slab for transaction amount
            while($dt = $cm_pk_rw->fetch_assoc()){
                    if($trans['AMOUNT'] >= $dt['MIN_AMOUNT'] && $trans['AMOUNT']  <= $dt['MAX_AMOUNT']){
                        $plan_id = $dt['ID'];
                        break;
                    }
                }
            // get full detail of the slab row
            $pack = $con->query("select * from slab_commission where ID='$plan_id'")->fetch_assoc();
            
           //check commision type 
        if($pack['TYPE'] == "PERCENTAGE"){
            $com = $pack['AMOUNT'];
            //check amount commission type
            if($pack['AMOUNT_TYPE'] == "DEBIT"){
                $com_amount = ($trans['AMOUNT']/100)*$com;
                $gst = ($com_amount/100)*$pack['GST'];
                $tds = ($com_amount/100)*$pack['TDS'];
                $givenCom = $com_amount-$gst-$tds;
                $update_bal = $crnt_bal-$givenCom;
            }
            else{
                $com_amount = ($trans['AMOUNT']/100)*$com;
                $gst = ($com_amount/100)*$pack['GST'];
                $tds = ($com_amount/100)*$pack['TDS'];
                $givenCom = $com_amount-$gst-$tds;
                $update_bal = $crnt_bal+$givenCom;
            }
        }
        else if($pack['TYPE'] == "FLAT"){
              $com = $pack['AMOUNT'];
              if($pack['AMOUNT_TYPE'] == "DEBIT"){
                $com_amount = $com;
                $gst = ($com_amount/100)*$pack['GST'];
                $tds = ($com_amount/100)*$pack['TDS'];
                $givenCom = $com_amount-$gst-$tds;
                $update_bal = $crnt_bal-$givenCom;
              }
              else{
                $com_amount = $com;
                $gst = ($com_amount/100)*$pack['GST'];
                $tds = ($com_amount/100)*$pack['TDS'];
                $givenCom = $com_amount-$gst-$tds;
                $update_bal = $crnt_bal+$givenCom;
              }
        }
        else{
            $com_amount = 0;
            $gst = 0;
            $tds = 0;
            $givenCom = 0;
            $update_bal = $crnt_bal;
        }
        
        
        $con->query("update `report` set AFTER_AMOUNT='$update_aeps_bal'  where REFERENCE_ID='$ref_id' and USER_ID='$user_id'");
        
        $con->query("update user set MAIN_BAL='$update_bal', AEPS_BAL='$update_aeps_bal'  where ID='$user_id' and USER_TYPE='$usertype'");
         $con->query("INSERT INTO `commission_report`(`SERVICE`, `REFFRENCE`, `USER_ID`, `USER_TYPE`, `AMOUNT`, `COMMISSION`,`GST` ,`TDS`, `TIME`) 
                    VALUES ('AEPS','$ref_id','$user_id','$usertype','".$trans['AMOUNT']."','$givenCom','$gst' ,'$tds' ,'$time')");
                    
                    
        insert_allreport($user_id  ,$ref_id , "AEPS Commission" ,$crnt_bal , $update_bal , $givenCom , "Credit" , "AEPS Transaction Commission", $ip_address, $device);
        if(strtolower($owner) != "admin"){
            $i = 1;
            while($user_type_rows >= $i){
                $i++;
                     $user2 = $con->query("select * from user  where ID='$owner'")->fetch_assoc();
                    $owner2 = $user2['OWNER_ID'];
                    $us_type = $user2['USER_TYPE'];
                    $crnt_bal = $user2['MAIN_BAL'];
                    $crnt_aeps_bal = $user2['AEPS_BAL'];
                    $crnt_trans_bal = $trans['AMOUNT'];
                    $update_aeps_bal = $crnt_aeps_bal+$crnt_trans_bal;
                    $com2_id = $user2['AEPS_COMM'];
                    // give commision to owner 
                        //check slab commission package
                          $cm_pk_rw = $con->query("select * from slab_commission where COMM_PACK_ID='$com2_id' order by ID asc");
                        //   code for fetch perticuler slab for transaction amount
                            while($dt = $cm_pk_rw->fetch_assoc()){
                                    if($trans['AMOUNT'] >= $dt['MIN_AMOUNT'] && $trans['AMOUNT']  <= $dt['MAX_AMOUNT']){
                                        $plan_id = $dt['ID'];
                                        break;
                                    }
                                }
                            // get full detail of the slab row
                            $pack = $con->query("select * from slab_commission where ID='$plan_id'")->fetch_assoc();
                           //check commision type 
                        if($pack['TYPE'] == "PERCENTAGE"){
                            $com = $pack['AMOUNT'];
                            //check amount commission type
                            if($pack['AMOUNT_TYPE'] == "DEBIT"){
                                $com_amount = ($trans['AMOUNT']/100)*$com;
                                $gst = ($com_amount/100)*$pack['GST'];
                                $tds = ($com_amount/100)*$pack['TDS'];
                                $givenCom = $com_amount-$gst-$tds;
                                $update_bal = $crnt_bal-$givenCom;
                            }
                            else{
                                $com_amount = ($trans['AMOUNT']/100)*$com;
                                $gst = ($com_amount/100)*$pack['GST'];
                                $tds = ($com_amount/100)*$pack['TDS'];
                                $givenCom = $com_amount-$gst-$tds;
                                $update_bal = $crnt_bal+$givenCom;
                            }
                        }
                        else if($pack['TYPE'] == "FLAT"){
                              $com = $pack['AMOUNT'];
                              if($pack['AMOUNT_TYPE'] == "DEBIT"){
                                $com_amount = $com;
                                $gst = ($com_amount/100)*$pack['GST'];
                                $tds = ($com_amount/100)*$pack['TDS'];
                                $givenCom = $com_amount-$gst-$tds;
                                $update_bal = $crnt_bal-$givenCom;
                              }
                              else{
                                $com_amount = $com;
                                $gst = ($com_amount/100)*$pack['GST'];
                                $tds = ($com_amount/100)*$pack['TDS'];
                                $givenCom = $com_amount-$gst-$tds;
                                $update_bal = $crnt_bal+$givenCom;
                              }
                        }
                        else{
                            $com_amount = 0;
                            $gst = 0;
                            $tds = 0;
                            $givenCom = 0;
                            $update_bal = $crnt_bal;
                        }
                        $con->query("update user set MAIN_BAL='$update_bal', AEPS_BAL='$update_aeps_bal'  where ID='$owner'");
                         $con->query("INSERT INTO `commission_report`(`SERVICE`, `REFFRENCE`, `USER_ID`, `USER_TYPE`, `AMOUNT`, `COMMISSION`,`GST` ,`TDS`, `TIME`) 
                                    VALUES ('AEPS','$ref_id','$owner','$us_type','".$trans['AMOUNT']."','$givenCom','$gst' ,'$tds' ,'$time')");
                        insert_allreport($owner  ,$ref_id , "AEPS Commission" ,$crnt_bal , $update_bal , $givenCom , "Credit" , "AEPS Transaction Commission", $ip_address, $device);
                    $owner = $owner2;
                    if(strtolower($owner2) == "admin"){
                        break;
                    }
            }
        }
    
    // return true;
}
// End Micro comission Start 


?>