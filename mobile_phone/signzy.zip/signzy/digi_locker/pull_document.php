<?php

$requestId = $_POST['requestId'];
$name = $_POST['name'];
$panNumber = $_POST['panNumber'];

include("../../my_curls/myCurl.php");
include("../../includes/config.php");
include("../../../Agent/Backend/Functions/all_function.php");
date_default_timezone_set("Asia/Kolkata");
$singzyData = getsignzyAuth();
extract($singzyData);


if(isset($_POST['pull_document'])){
    $arr = array(
       "task" => "pullDocuments",
      "essentials"=> [
          "requestId"=> $requestId,
          "docType"=> "PANCR",
          "name"=> $name,
          "panNumber"=> $panNumber
      ]
    );
    
    $postData = json_encode($arr);    
    $url = "https://preproduction.signzy.tech/api/v2/patrons/$userId/digilockers";
    $header = array(
        "Authorization: $id",
        "accept: */*",
        "accept-language: en-US,en;q=0.8",
        "content-type: application/json"
    );
    
    $response = postCurl($postData, $url, $header);
    $errors = json_decode($response);
    $errorCode = $errors->error->statusCode;
    $errorMessage =$errors->error->message;
    if($errorMessage=="" || $errorMessage==null){
        echo json_encode(["message"=>"Response Recieved", "response_code"=>1, "status"=>true, "receivableData"=>$errors]);
    }
    else{
        echo json_encode(["message"=>$errorMessage, "response_code"=>300, "status"=>false]);
    }
}

?>