<?php
    
    $json = file_get_contents('php://input');
    $data = json_decode($json);
    
    echo $json;
    
    echo "Processing, Please wait..."
?>