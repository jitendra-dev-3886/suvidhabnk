<?php

    include("../../my_curls/myCurl.php");
    include("../../util/uploader.php");
    
    include("../../includes/config.php");
    include("../../../Agent/Backend/Functions/all_function.php");
    date_default_timezone_set("Asia/Kolkata");
    $singzyData = getsignzyAuthLive();
    extract($singzyData);
    

    $json = file_get_contents('php://input');
    $data = json_decode($json);

    if($data!=null || $data!=""){
        
        $imageStringF = $data->fImageBase64;
        $mobile = $data->mobile;
        // $imageStringS = $data->sImageBase64;
        
        $Firstimagename = uploadImage($imageStringF, $mobile);
        // $SecondImageName = uploadImage($imageStringS, $mobile);
        
        $furl = "https://paydeer.app/mobile_phone/signzy/videoVerification/".$Firstimagename;
        // $surl = "https://paydeer.app/mobile_phone/signzy/videoVerification/".$SecondImageName;
        
        $givenOTP = mt_rand(99999 , 1000000);
        
        $matchImage = array(
                $furl
            );

   $postData = json_encode(array(
       
    "task" => "url",
      "essentials" => [
          "matchImage" => $matchImage,
          "customVideoRecordTime" => "10",
          "hideTopLogo" => false,
          "hideBottomLogo" => true,
          "callbackUrl" => "https://paydeer.app/mobile_phone/signzy/callback.php",
          "redirectUrl" => "https://paydeer.app/mobile_phone/signzy/digi_locker/redirect_url.php",
          "idCardVerification" => false,
          "languageCode" => "en",
          "customText" => "$givenOTP",
          "customizations"=>[
              "logoUrl" => "https://pbs.twimg.com/profile_images/1451144624685273093/9MzOvU93_400x400.jpg"
            ]
      ]
    
    ));
    
    
    $url = "https://signzy.tech/api/v2/patrons/$userId/videoiframes";
    $header = array(
        "Authorization: $id",
        "accept: */*",
        "accept-language: en-US,en;q=0.8",
        "content-type: application/json"
    );
    
    $response = postCurl($postData, $url, $header);
    $errors = json_decode($response);
    $errorCode = $errors->error->statusCode;
    $errorMessage =$errors->error->message;
    if($errorMessage=="" || $errorMessage==null){
        echo json_encode(["message"=>"Response Recieved", "response_code"=>1, "status"=>true, "receivableData"=>$errors]);
    }
    else{
        echo json_encode(["message"=>$errorMessage, "response_code"=>300, "status"=>false]);
    }
}


?>