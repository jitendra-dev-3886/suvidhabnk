<?php

include("../incldues/config.php");
function check_aeps_user($user_id , $user_type){
    global $con;
    global $paysprint;
    $user = $con->query("select * from aeps_merchant where  MERCHANTCODE='".$paysprint['MERCHANT_CODE'].$user_id."' ");
     if($user->num_rows == 0){
         return $user->num_rows ;
     }
     else{
         return $user->fetch_assoc();
     }
    //   return "select * from dmt_user where USER_ID='$user_id' and USER_TYPE='$user_type'";
}

function getbank(){
    global $paysprint;
    $curl = curl_init();
    $token = create_token();
    curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://api.paysprint.in/api/v1/service/aeps/banklist/index',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_HTTPHEADER => array(
          "Authorisedkey:".$paysprint['AUTHORISED_KEY'],
            "Token:".$token
      ),
    ));
    
    $response = curl_exec($curl);
    curl_close($curl);
    return $response;
}



function get_aeps_charge($id , $amount){
    global $con;
     $cm_pk_rw = $con->query("select * from slab_commission where COMM_PACK_ID='$id' order by ID asc");
    while($dt = $cm_pk_rw->fetch_assoc()){
        // print_r($dt);
            if($amount >= $dt['MIN_AMOUNT'] && $amount <= $dt['MAX_AMOUNT']){
                $plan_id = $dt['ID'];
                break;
            }
        }
    $plan_dt = $con->query("select * from slab_commission where ID='$plan_id'")->fetch_assoc();
    $charge = $plan_dt['COMMISSION_AMOUNT'];
    return $charge;
}


// New Function
function give_aeps_com($ref_id , $user_id , $usertype, $ip_address, $device){
      global $con;
    // echo "AEPS com working \n";
$time = date("Y-m-d g:i:s A");
        $user_type_rows = $con->query("select * from user_type ")->num_rows;
        $trans = $con->query("select * from aeps_transactions where REFFRENCE_ID='$ref_id'")->fetch_assoc();
        $user = $con->query("select * from user  where ID='$user_id' and USER_TYPE='$usertype'")->fetch_assoc();
        $owner = $user['OWNER_ID'];
        $crnt_bal = $user['MAIN_BAL'];
        $com_id = $user['AEPS_COMM'];
        
        //check slab commission package
          $cm_pk_rw = $con->query("select * from slab_commission where COMM_PACK_ID='$com_id' order by ID asc");
        //   code for fetch perticuler slab for transaction amount
            while($dt = $cm_pk_rw->fetch_assoc()){
                    if($trans['AMOUNT'] >= $dt['MIN_AMOUNT'] && $trans['AMOUNT']  <= $dt['MAX_AMOUNT']){
                        $plan_id = $dt['ID'];
                        break;
                    }
                }
            // get full detail of the slab row
            $pack = $con->query("select * from slab_commission where ID='$plan_id'")->fetch_assoc();
            
           //check commision type 
        if($pack['TYPE'] == "PERCENTAGE"){
            $com = $pack['AMOUNT'];
            //check amount commission type
            if($pack['AMOUNT_TYPE'] == "DEBIT"){
                $com_amount = ($trans['AMOUNT']/100)*$com;
                $gst = ($com_amount/100)*$pack['GST'];
                $tds = ($com_amount/100)*$pack['TDS'];
                $givenCom = $com_amount-$gst-$tds;
                $update_bal = $crnt_bal-$givenCom;
            }
            else{
                $com_amount = ($trans['AMOUNT']/100)*$com;
                $gst = ($com_amount/100)*$pack['GST'];
                $tds = ($com_amount/100)*$pack['TDS'];
                $givenCom = $com_amount-$gst-$tds;
                $update_bal = $crnt_bal+$givenCom;
            }
        }
        else if($pack['TYPE'] == "FLAT"){
              $com = $pack['AMOUNT'];
              if($pack['AMOUNT_TYPE'] == "DEBIT"){
                $com_amount = $com;
                $gst = ($com_amount/100)*$pack['GST'];
                $tds = ($com_amount/100)*$pack['TDS'];
                $givenCom = $com_amount-$gst-$tds;
                $update_bal = $crnt_bal-$givenCom;
              }
              else{
                $com_amount = $com;
                $gst = ($com_amount/100)*$pack['GST'];
                $tds = ($com_amount/100)*$pack['TDS'];
                $givenCom = $com_amount-$gst-$tds;
                $update_bal = $crnt_bal+$givenCom;
              }
        }
        else{
            $com_amount = 0;
            $gst = 0;
            $tds = 0;
            $givenCom = 0;
            $update_bal = $crnt_bal;
        }
        $con->query("update user set MAIN_BAL='$update_bal'  where ID='$user_id' and USER_TYPE='$usertype'");
         $con->query("INSERT INTO `commission_report`(`SERVICE`, `REFFRENCE`, `USER_ID`, `USER_TYPE`, `AMOUNT`, `COMMISSION`,`GST` ,`TDS`, `TIME`) 
                    VALUES ('AEPS','$ref_id','$user_id','$usertype','".$trans['AMOUNT']."','$givenCom','$gst' ,'$tds' ,'$time')");
        insert_allreport($user_id  ,$ref_id , "AEPS Commission" ,$crnt_bal , $update_bal , $givenCom , "Credit" , "AEPS Transaction Commission", $ip_address, $device);
        if(strtolower($owner) != "admin"){
            $i = 1;
            while($user_type_rows >= $i){
                $i++;
                     $user2 = $con->query("select * from user  where ID='$owner'")->fetch_assoc();
                    $owner2 = $user2['OWNER_ID'];
                    $us_type = $user2['USER_TYPE'];
                    $crnt_bal = $user2['MAIN_BAL'];
                    $com2_id = $user2['AEPS_COMM'];
                    // give commision to owner 
                        //check slab commission package
                          $cm_pk_rw = $con->query("select * from slab_commission where COMM_PACK_ID='$com2_id' order by ID asc");
                        //   code for fetch perticuler slab for transaction amount
                            while($dt = $cm_pk_rw->fetch_assoc()){
                                    if($trans['AMOUNT'] >= $dt['MIN_AMOUNT'] && $trans['AMOUNT']  <= $dt['MAX_AMOUNT']){
                                        $plan_id = $dt['ID'];
                                        break;
                                    }
                                }
                            // get full detail of the slab row
                            $pack = $con->query("select * from slab_commission where ID='$plan_id'")->fetch_assoc();
                           //check commision type 
                        if($pack['TYPE'] == "PERCENTAGE"){
                            $com = $pack['AMOUNT'];
                            //check amount commission type
                            if($pack['AMOUNT_TYPE'] == "DEBIT"){
                                $com_amount = ($trans['AMOUNT']/100)*$com;
                                $gst = ($com_amount/100)*$pack['GST'];
                                $tds = ($com_amount/100)*$pack['TDS'];
                                $givenCom = $com_amount-$gst-$tds;
                                $update_bal = $crnt_bal-$givenCom;
                            }
                            else{
                                $com_amount = ($trans['AMOUNT']/100)*$com;
                                $gst = ($com_amount/100)*$pack['GST'];
                                $tds = ($com_amount/100)*$pack['TDS'];
                                $givenCom = $com_amount-$gst-$tds;
                                $update_bal = $crnt_bal+$givenCom;
                            }
                        }
                        else if($pack['TYPE'] == "FLAT"){
                              $com = $pack['AMOUNT'];
                              if($pack['AMOUNT_TYPE'] == "DEBIT"){
                                $com_amount = $com;
                                $gst = ($com_amount/100)*$pack['GST'];
                                $tds = ($com_amount/100)*$pack['TDS'];
                                $givenCom = $com_amount-$gst-$tds;
                                $update_bal = $crnt_bal-$givenCom;
                              }
                              else{
                                $com_amount = $com;
                                $gst = ($com_amount/100)*$pack['GST'];
                                $tds = ($com_amount/100)*$pack['TDS'];
                                $givenCom = $com_amount-$gst-$tds;
                                $update_bal = $crnt_bal+$givenCom;
                              }
                        }
                        else{
                            $com_amount = 0;
                            $gst = 0;
                            $tds = 0;
                            $givenCom = 0;
                            $update_bal = $crnt_bal;
                        }
                        $con->query("update user set MAIN_BAL='$update_bal'  where ID='$owner'");
                         $con->query("INSERT INTO `commission_report`(`SERVICE`, `REFFRENCE`, `USER_ID`, `USER_TYPE`, `AMOUNT`, `COMMISSION`,`GST` ,`TDS`, `TIME`) 
                                    VALUES ('AEPS','$ref_id','$owner','$us_type','".$trans['AMOUNT']."','$givenCom','$gst' ,'$tds' ,'$time')");
                        insert_allreport($owner  ,$ref_id , "AEPS Commission" ,$crnt_bal , $update_bal , $givenCom , "Credit" , "AEPS Transaction Commission", $ip_address, $device);
                    $owner = $owner2;
                    if(strtolower($owner2) == "admin"){
                        break;
                    }
            }
        }
    
    // return true;
}
// New Function

// Start Adhar comission Start
function aadhar_com($ref_id , $user_id , $usertype, $ip_address, $device){
   global $con;
    // echo "AEPS com working \n";
$time = date("Y-m-d g:i:s A");
        $user_type_rows = $con->query("select * from user_type ")->num_rows;
        $trans = $con->query("select * from aeps_transactions where REFFRENCE_ID='$ref_id'")->fetch_assoc();
        $user = $con->query("select * from user  where ID='$user_id' and USER_TYPE='$usertype'")->fetch_assoc();
        $owner = $user['OWNER_ID'];
        $crnt_bal = $user['MAIN_BAL'];
        $com_id = $user['AADHAR_COMM'];
        
        //check slab commission package
          $cm_pk_rw = $con->query("select * from slab_commission where COMM_PACK_ID='$com_id' order by ID asc");
        //   code for fetch perticuler slab for transaction amount
            while($dt = $cm_pk_rw->fetch_assoc()){
                    if($trans['AMOUNT'] >= $dt['MIN_AMOUNT'] && $trans['AMOUNT']  <= $dt['MAX_AMOUNT']){
                        $plan_id = $dt['ID'];
                        break;
                    }
                }
            // get full detail of the slab row
            $pack = $con->query("select * from slab_commission where ID='$plan_id'")->fetch_assoc();
            
           //check commision type 
        if($pack['TYPE'] == "PERCENTAGE"){
            $com = $pack['AMOUNT'];
            //check amount commission type
            if($pack['AMOUNT_TYPE'] == "DEBIT"){
                $com_amount = ($trans['AMOUNT']/100)*$com;
                $gst = ($com_amount/100)*$pack['GST'];
                $tds = ($com_amount/100)*$pack['TDS'];
                $givenCom = $com_amount-$gst-$tds;
                $update_bal = $crnt_bal-$givenCom;
            }
            else{
                $com_amount = ($trans['AMOUNT']/100)*$com;
                $gst = ($com_amount/100)*$pack['GST'];
                $tds = ($com_amount/100)*$pack['TDS'];
                $givenCom = $com_amount-$gst-$tds;
                $update_bal = $crnt_bal+$givenCom;
            }
        }
        else if($pack['TYPE'] == "FLAT"){
              $com = $pack['AMOUNT'];
              if($pack['AMOUNT_TYPE'] == "DEBIT"){
                $com_amount = $com;
                $gst = ($com_amount/100)*$pack['GST'];
                $tds = ($com_amount/100)*$pack['TDS'];
                $givenCom = $com_amount-$gst-$tds;
                $update_bal = $crnt_bal-$givenCom;
              }
              else{
                $com_amount = $com;
                $gst = ($com_amount/100)*$pack['GST'];
                $tds = ($com_amount/100)*$pack['TDS'];
                $givenCom = $com_amount-$gst-$tds;
                $update_bal = $crnt_bal+$givenCom;
              }
        }
        else{
            $com_amount = 0;
            $gst = 0;
            $tds = 0;
            $givenCom = 0;
            $update_bal = $crnt_bal;
        }
        $con->query("update user set MAIN_BAL='$update_bal'  where ID='$user_id' and USER_TYPE='$usertype'");
         $con->query("INSERT INTO `commission_report`(`SERVICE`, `REFFRENCE`, `USER_ID`, `USER_TYPE`, `AMOUNT`, `COMMISSION`,`GST` ,`TDS`, `TIME`) 
                    VALUES ('AADHARPAY','$ref_id','$user_id','$usertype','".$trans['AMOUNT']."','$givenCom','$gst' ,'$tds' ,'$time')");
        insert_allreport($user_id  ,$ref_id , "AadharPay Commission" ,$crnt_bal , $update_bal , $givenCom , "Credit" , "AadharPay Transaction Commission", $ip_address, $device);
        if(strtolower($owner) != "admin"){
            $i = 1;
            while($user_type_rows >= $i){
                $i++;
                     $user2 = $con->query("select * from user  where ID='$owner'")->fetch_assoc();
                    $owner2 = $user2['OWNER_ID'];
                    $us_type = $user2['USER_TYPE'];
                    $crnt_bal = $user2['MAIN_BAL'];
                    $com2_id = $user2['AADHAR_COMM'];
                    // give commision to owner 
                        //check slab commission package
                          $cm_pk_rw = $con->query("select * from slab_commission where COMM_PACK_ID='$com2_id' order by ID asc");
                        //   code for fetch perticuler slab for transaction amount
                            while($dt = $cm_pk_rw->fetch_assoc()){
                                    if($trans['AMOUNT'] >= $dt['MIN_AMOUNT'] && $trans['AMOUNT']  <= $dt['MAX_AMOUNT']){
                                        $plan_id = $dt['ID'];
                                        break;
                                    }
                                }
                            // get full detail of the slab row
                            $pack = $con->query("select * from slab_commission where ID='$plan_id'")->fetch_assoc();
                           //check commision type 
                        if($pack['TYPE'] == "PERCENTAGE"){
                            $com = $pack['AMOUNT'];
                            //check amount commission type
                            if($pack['AMOUNT_TYPE'] == "DEBIT"){
                                $com_amount = ($trans['AMOUNT']/100)*$com;
                                $gst = ($com_amount/100)*$pack['GST'];
                                $tds = ($com_amount/100)*$pack['TDS'];
                                $givenCom = $com_amount-$gst-$tds;
                                $update_bal = $crnt_bal-$givenCom;
                            }
                            else{
                                $com_amount = ($trans['AMOUNT']/100)*$com;
                                $gst = ($com_amount/100)*$pack['GST'];
                                $tds = ($com_amount/100)*$pack['TDS'];
                                $givenCom = $com_amount-$gst-$tds;
                                $update_bal = $crnt_bal+$givenCom;
                            }
                        }
                        else if($pack['TYPE'] == "FLAT"){
                              $com = $pack['AMOUNT'];
                              if($pack['AMOUNT_TYPE'] == "DEBIT"){
                                $com_amount = $com;
                                $gst = ($com_amount/100)*$pack['GST'];
                                $tds = ($com_amount/100)*$pack['TDS'];
                                $givenCom = $com_amount-$gst-$tds;
                                $update_bal = $crnt_bal-$givenCom;
                              }
                              else{
                                $com_amount = $com;
                                $gst = ($com_amount/100)*$pack['GST'];
                                $tds = ($com_amount/100)*$pack['TDS'];
                                $givenCom = $com_amount-$gst-$tds;
                                $update_bal = $crnt_bal+$givenCom;
                              }
                        }
                        else{
                            $com_amount = 0;
                            $gst = 0;
                            $tds = 0;
                            $givenCom = 0;
                            $update_bal = $crnt_bal;
                        }
                        $con->query("update user set MAIN_BAL='$update_bal'  where ID='$owner'");
                         $con->query("INSERT INTO `commission_report`(`SERVICE`, `REFFRENCE`, `USER_ID`, `USER_TYPE`, `AMOUNT`, `COMMISSION`,`GST` ,`TDS`, `TIME`) 
                                    VALUES ('AADHARPAY','$ref_id','$owner','$us_type','".$trans['AMOUNT']."','$givenCom','$gst' ,'$tds' ,'$time')");
                        insert_allreport($owner  ,$ref_id , "AadharPay Commission" ,$crnt_bal , $update_bal , $givenCom , "Credit" , "AadharPay Transaction Commission", $ip_address, $device);
                    $owner = $owner2;
                    if(strtolower($owner2) == "admin"){
                        break;
                    }
            }
        }
    
    // return true;
}
?>